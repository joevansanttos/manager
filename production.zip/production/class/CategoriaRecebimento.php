<?php

	class CategoriaRecebimento extends Categoria{
		

	}

?>