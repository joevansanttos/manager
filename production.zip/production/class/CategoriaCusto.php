<?php

	class CategoriaCusto extends Categoria{
		

	}

?>