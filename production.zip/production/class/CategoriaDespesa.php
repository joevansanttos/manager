<?php

	class CategoriaDespesa extends Categoria{

	}

?>