<?php	 
	require_once "../views/cabecalho.php"; 
?>


<?php	require_once "css.php"; ?>

<h3>Pós-Venda</h3>

<?php	require_once "body.php"; ?>

<?php	require_once "script.php"; ?>


<?php	require_once "rodape.php"; ?>