<?php	
	require "../includes/cabecalho.php"; 
?>
<h3>Dashboard</h3>

<?php	require "../includes/body.php"; ?>

<?php	require "../includes/script.php"; ?>


<?php	require "../includes/rodape.php"; ?>