<?php
	//$conexao = mysqli_connect("localhost", "root", "", "manager");
	$conexao = mysqli_connect("127.0.0.1", "root", "", "manager");
	mysqli_set_charset($conexao, "utf8");
?>