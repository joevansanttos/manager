<?php
  
  
  // Inclui o arquivo class.phpmailer.php localizado na pasta class
  
  //header("Location: ../profiles/pi-profile.php?cod_pi=$cod_pi");

?>